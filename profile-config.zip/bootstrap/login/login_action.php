<?php
try
{
	include 'connexion.php' ;
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

if(isset($_POST['login'])) {

$email= $_POST['email'];
$password = $_POST['password'] ;


$req = $idcon->prepare("SELECT * FROM formulaire WHERE email= ? AND password= ?");
$req->execute(array($email, $password));
if($donnees = $req->fetch())
{
	session_start();
	$_SESSION['id']=$donnees['id'];
	$_SESSION['avatar']=$donnees['avatar'];
	$_SESSION['firstname']=$donnees['firstname'];
	$_SESSION['birthday']=$donnees['birthday'];
	$_SESSION['password']=$donnees['password'];
	header('Location:../index.php');

}

else     	echo "<script>alert(\"Email ou mot de passe incorrect  \")</script>";


}


?>