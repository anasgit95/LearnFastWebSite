<?php 
Require "prof.php";

try
{
	include 'connexion.php' ;
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
if (isset($_SESSION['id'])) {
$req = $idcon->prepare("SELECT * FROM formulaire WHERE id= ? ");
$req->execute(array($_SESSION['id']));
$donnes=$req->fetch(); 
$photo ="images/".$_SESSION['avatar'];
?>
<style>

</style>
<head>
		<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
</head>
<body>
<form action="sava.php"  method="POST">
<div class="login-box">
	<ul <ul style="list-style-type:none;">

  <li>	 <h1>Profile</h1></li>
  <li>   <img src= "<?php echo $photo ?> "alt="" width="150" height="150" style="border-radius: 15px 50px"> <i class="fas fa-pencil-alt"></i>
</li>
 	 </ul>
 	 
  <div class="textbox">
<i class="fas fa-user"></i>
	        <input type="textbox" placeholder="<?php echo $donnes['firstname'] ?>" name="firstname"><i class="fas fa-pencil-alt"></i> </a> 
	   </div>
	     <div class="textbox">
<i class="fas fa-user"></i>
	        <p> <?php echo $donnes['lastname'] ?> <a href="lastname.php"> <i class="fas fa-pencil-alt"></i> </a> </p>
	   </div>
  <div class="textbox">
  	<i class="fas fa-envelope-square"></i>
	        <p> <?php echo $donnes['email'] ?> <a href="email.php>" <i class="fas fa-pencil-alt"></i> </a></p>
	   </div>
	     <div class="textbox">
           <i class="fas fa-unlock-alt"></i>
	        <p> ******** <a href="password.php"> <i class="fas fa-pencil-alt"></i> </a></p>
	   </div>
	   <div class="textbox">
	   	<i class="fas fa-birthday-cake"></i>
	        <p> <?php echo $donnes['birthday'] ?> <a href="birthday.php" ><i class="fas fa-pencil-alt"></i> </a></p>

	   </div>
	   <?php 
	  ?>




    <input type="submit" value="Enregistrer" name="save" class="login100-form-btn">

</form>
</body>
<?php } 

else     	echo "<script>alert(\"Tu dois ce connecter Monsieur  \")</script>";
?>

