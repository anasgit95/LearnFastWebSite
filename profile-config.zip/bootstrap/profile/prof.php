<?php 
session_start();


Require  'connexion.php' ;
if (isset($_POST['save-user']) )
{


    $profileImageName=time().'_'.$_FILES['avatar']['name'];
    $target='images/'.$profileImageName ;
   

   if ( move_uploaded_file($_FILES['avatar']['tmp_name'],$target)) {

$stmt = $idcon->prepare('UPDATE formulaire SET  avatar = :avatar WHERE id = :id');
$stmt->execute(array(
	'avatar' => $profileImageName,
	'id' =>$_SESSION['id'],
	
	));

 $_SESSION['avatar']=$profileImageName;
}

header('location: profile.php');
	}
?>
