<?php
session_start();


if (isset($_files['avatar']) AND !empty($_files['avatar']['name']))
{   
	$tailleMax =2097152;
	$extensionValides =array('jpg','jpeg','gif','png');
	if($_files['avatar']['size']<=$tailleMax) {
		$extensionUpload =strtolower(substr(strrchr($_files['avatar']['name'],'.'),1));
		if(in_array($extensionUpload,$extensionValides))
		{
         $chemin="membres/avatars/".$_SESSION['id'].".".$extensionUpload;
         $resultat=move_uploaded_file($_files['avatar']['tmp_name'], $chemin);
         if($resultat)
         {
         
         $updateavatar =$idcon->prepare('UPDATE formulaire set avatar = :avatar where id=?');

        $updateavatar->execute(array(
        'avatar' =>$_SESSION['id'].".".$extensionUpload,$_SESSION['id']
        ));
         header('location: ../index.php');
         }
         else {
         	$msg="erreur durant l'imporation";
         }
		}
		else {
			$msg="format invalide ";
		}

	}
	else {
		$msg="Votre photo de profil ne doit pas dépasser 2Mo";
	}
}
	echo $msg;
