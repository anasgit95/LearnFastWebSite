<?php 
session_start() ; 
if (isset($_SESSION['id'])) {
		header('Location: https://www.youtube.com/watch?v=4UyeV3EPBS8');

}
else  header('Location:login/login.php')
 ;

?>