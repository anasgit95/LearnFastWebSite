<?php 

  	include 'connexion.php' ;
$req = $idcon->prepare("delete FROM formulaire WHERE id=?");
$req->execute(array($_GET['id']));
header('Location:admin.php');

  	?>