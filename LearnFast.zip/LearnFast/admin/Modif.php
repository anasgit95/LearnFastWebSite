
<<!DOCTYPE html>
<html>
<head>
	<title>Modifier Profile</title>
	 <link rel="stylesheet" href="new.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
</head>



<?php 
session_start() ;
?>
<body>
	<div class="containers">
<table id="customers">
  <tr>
    <td>ID</td>
    <td>Nom </td>
    <td>lastname</td>
    <td>date de naissance </td>
    <td>EMAIL </td>
    <td>Type </td>
  
  </tr>
  <?php 
    include 'connexion.php' ;
	
  $req = $idcon->prepare("SELECT * FROM formulaire where id=? ");
$req->execute(array($_GET['id']));


while($donnees = $req->fetch())
{
	?>
	
  <tr>
  		<td> <input type="text" name="firstname" value="<?php echo $donnees['id'] ?>" >	 </td>

	<td> <input type="text" name="firstname" value="<?php echo $donnees['firstname'] ?>" >	 </td>
	<td> <input type="text" name="lastname" value="<?php echo $donnees['lastname'] ?>" >	 </td>
    <td> <input type="text" name="birthday" value="<?php echo $donnees['birthday'] ?>" >	 </td>
    <td> <input type="text" name="email" value="<?php echo $donnees['email'] ?>" >	 </td>
	<td> <input type="text" name="type" value="<?php echo $donnees['type'] ?>" >	 </td>

	</tr>
		
<?php 
}
?>
</table>
<button> Enrigestrer  </button>
</div>
</body>
</body>
</html>	