<?
if ($_POST['firstname']) {

$stmt = $idcon->prepare('UPDATE formulaire SET  firstname = :firstname WHERE id = :id');
$stmt->execute(array(
	'firstname' => $_POST['firstname'],
	'id' =>$_SESSION['id'],
	
	));