<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="new.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
</head>

<body>
  <div class="Search"> 
  <form action="admin.php" method="POST" >
	<h4> Gestion Des Comptes </h4>
  <input type="search" name="search"
       aria-label="Search through site content" id="search">

<button>Search</button>
</form>
</div>
<table id="customers">
  <tr>
    <td>ID</td>
    <td>Nom </td>
    <td>lastname</td>
    <td>date de naissance </td>
    <td>EMAIL </td>
    <td>Type </td>
  
  </tr>
  <?php 
    include 'connexion.php' ;
  if( isset($_POST['search'])) {
$req = $idcon->prepare("SELECT * FROM formulaire WHERE firstname= ? or lastname= ? and type='Client'");
$req->execute(array($_POST['search'], $_POST['search']));
  $_POST['Search']=' ';
  }
  else {
session_start();	
  $req = $idcon->prepare("SELECT * FROM formulaire where type='Client' ");
$req->execute();
}

while($donnees = $req->fetch())
{
	?>
	<tr>
    <td><?php echo $donnees['id'] ?> </td>
    <td><?php echo $donnees['firstname'] ?> </td>
    <td><?php echo $donnees['lastname'] ?> </td>
    <td><?php echo $donnees['birthday'] ?> </td>
    <td><?php echo $donnees['email'] ?> </td>
    <td><?php echo $donnees['type'] ?> </td>
	<td> <?php echo " <a href='Modif.php?id=" . $donnees['id'] . "'>"  ?> Modifier </td> 
  <td> <?php echo " <a href='Supprimer.php?id=" . $donnees['id'] . "'>"  ?> Supprimer </td> 
	 <tr>
<?php 
}
?>
</table>
  <?php 
while($donnees = $req->fetch()) 
{
echo "<li>" . $donnees['id'] . " : " . $donnees['firstname'] ."  " . $donnees['lastname']. " ". $donnees['email'] . 
" | <a href='Modif.php?id=" . $donnees['id'] . "'>
Supprimer
</a> | <a href='modif-sql.php?id=" . $donnees['id'] . "'>
modifier
</a>";
}
?>
</body>