<?php Require 'head.php' ;
include 'connexion.php' ;
session_start();
$welcome=$_SESSION['firstname'];
$deconnexion='Deconnexion';
$nothing = " " ;
$image="../profile/images/".$_SESSION['avatar'];
$type =$_SESSION['type'];

 ?>

<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="canonical" href="https://html5-templates.com/" />
    <title>Education WebSite</title>
  <meta name="description" content="A minimalist Bootstrap theme by StartBootstrap. Contains everything you need to get started building your website. All you have to do is change the text and images.">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/modern-business.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="new.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
</head>

<body>
  <?php 

     form_head($welcome,$deconnexion,$nothing,$image,$type);
if (isset($_POST['firstname'])) {
$stmt = $idcon->prepare('UPDATE formulaire SET  firstname = :firstname,lastname= :lastname ,email= :email, birthday= :birthday,type= :type WHERE id = :id');
$stmt->execute(array(
  'firstname' => $_POST['firstname'],
  'lastname'=>$_POST['lastname'],
  'email'=>$_POST['email'],
  'birthday'=>$_POST['birthday'],
  'type'=>$_POST['type'],
  'id' =>$_SESSION['idclient'],
  
  ));
  

}
  ?>
  <div class="Con"> 
  <form action="admin.php" method="POST" >
	<h4> Gestion Des Comptes </h4>
  <input type="search" name="search"
       aria-label="Search through site content" id="search">

<button>Search</button>
</form>
</div>
<table id="customers">
  <tr>
    <td>ID</td>
    <td>Nom </td>
    <td>lastname</td>
    <td>date de naissance </td>
    <td>EMAIL </td>
    <td>Type </td>
  
  </tr>
  <?php 
    
  if( isset($_POST['search'])) {
$req = $idcon->prepare("SELECT * FROM formulaire WHERE firstname= ? or lastname= ? and type='Client'");
$req->execute(array($_POST['search'], $_POST['search']));
  $_POST['Search']=' ';
  }
  else {

  $req = $idcon->prepare("SELECT * FROM formulaire where type='Client' ");
$req->execute();
}

while($donnees = $req->fetch())
{
	?>
	<tr>
    <td><?php echo $donnees['id'] ?> </td>
    <td><?php echo $donnees['firstname'] ?> </td>
    <td><?php echo $donnees['lastname'] ?> </td>
    <td><?php echo $donnees['birthday'] ?> </td>
    <td><?php echo $donnees['email'] ?> </td>
    <td><?php echo $donnees['type'] ?> </td>
	<td> <button><?php echo " <a href='Modif.php?id=" . $donnees['id'] . "'>"  ?> Modifier </button></td> 
  <td> <button><?php echo " <a href='Supprimer.php?id=" . $donnees['id'] . "'>"  ?> Supprimer </button> </td> 
	 <tr>
<?php 
}
?>
</table>
  <?php 

?>
</body>