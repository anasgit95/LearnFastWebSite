<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="new.css">
	<title>Test</title>
</head>
<body>
<header></header>
<div class ="container">
<div>
	<h1 class="profile">Profile</h1>
</div>

<div >
 <img src="<?php echo $photo ?> " alt="">
</div>
<div class="textbox">
	<p>FirstName</p>
	
	<p><?php echo $donnes['firstname'] ?> </p><a href="firstname.php">><i class="fas fa-edit" ></i></a>
</div>

?>
<div class="textbox"> 
	<p>Lastname</p>
 <p>  <?php echo $donnes['lastname'] ?> </p> <i class="fas fa-edit" ></i>

</div>
<div class="textbox">
	 <p>Email</p>
	 <p> <?php echo $donnes['email'] ?></p> <i class="fas fa-edit" ></i>

<!-- <input type="text" value="Email" name="Email"> <i class="fas fa-edit" ></i> -->



</div>
<div class="textbox">
	<p>Birthday</p>
	<p><?php echo $donnes['birthday'] ?></p>
	<!-- <input type="date" value="1995-02-17"  min="1994-04-01" max="2019-04-30"name=""><i class="fas fa-edit" ></i> -->
</div>
<div >
	<input  type="submit" value="Enrigestrer" name="Enrigestrer">

</div>
<footer></footer>
</body>
</html>