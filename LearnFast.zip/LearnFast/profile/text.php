<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="canonical" href="https://html5-templates.com/" />
    <title>Education WebSite</title>
    <meta name="description" content="A minimalist Bootstrap theme by StartBootstrap. Contains everything you need to get started building your website. All you have to do is change the text and images.">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/modern-business.css" rel="stylesheet">
    <link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>
<?php 
//commencer la session 

Require "form-profile.php";
Require '../head.php' ;
// verifier si l'utilisateur est connecté 
if( isset($_SESSION['id']) ) 
{
$welcome=$_SESSION['firstname'];
$deconnexion='Deconnexion';
$nothing = " " ;
$image="images/".$_SESSION['avatar'];



}
//sinon on change la form avec la login et l'inscription
else 
 {
    $welcome="to learn fast " ;
    $deconnexion="login ";
    $nothing="Inscription";
    $image="no";
}
 
?>
<body>
    <!-- Navigation -->
    <?php
     form_head($welcome,$deconnexion,$nothing,$image) ;

    form_profile(null,null,null,null);
         ?>
    