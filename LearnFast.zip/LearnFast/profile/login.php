<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">

	<title></title>
</head>
<body>
<div class="login-box">

 	 <h1>Login</h1>
  <img src= "<?php echo $photo ?> "alt="" width="150" height="150">
  <div class="textbox">
<i class="fas fa-user"></i>
	        <input type="text" placeholder="Username" name="">
	   </div>
  <div class="textbox">
  	<i class="fas fa-envelope-square"></i>
	        <input type="text" placeholder="email" name="">
	   </div>
	   <div class="textbox">
	   	<i class="fas fa-birthday-cake"></i>
	        <input type="text" placeholder="email" name="">
	   </div>
	   <input type="button" name="" value="Sign ">
</body>
</html>