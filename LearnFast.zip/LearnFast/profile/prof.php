<?php 
session_start();


Require  'connexion.php' ;
if (isset($_POST['save-user']) )
{


    $profileImageName=time().'_'.$_FILES['avatar']['name'];
    $target='images/'.$profileImageName ;
   

   if ( move_uploaded_file($_FILES['avatar']['tmp_name'],$target)) {

$stmt = $idcon->prepare('UPDATE formulaire SET  avatar = :avatar WHERE id = :id');
$stmt->execute(array(
	'avatar' => $profileImageName,
	'id' =>$_SESSION['id'],
	
	));

 $_SESSION['avatar']=$profileImageName;
}
  if ($_POST['firstname']) {

$stmt = $idcon->prepare('UPDATE formulaire SET  firstname = :firstname WHERE id = :id');
$stmt->execute(array(
	'firstname' => $_POST['firstname'],
	'id' =>$_SESSION['id'],
	
	));

 $_SESSION['firstname']=$_POST['firstname'];
}
if ($_POST['lastname']) {

$stmt = $idcon->prepare('UPDATE formulaire SET  lastname= :lastname WHERE id = :id');
$stmt->execute(array(
	'lastname' => $_POST['lastname'],
	'id' =>$_SESSION['id'],
	
	));

 $_SESSION['lastname']=$_POST['lastname'];
}

if ($_POST['email']) {
$req = $idcon->prepare('SELECT * FROM formulaire WHERE email = ?');
$req->execute(array($_POST['email']));
if ($donnees=$req->fetch()){
    	echo "<script>alert(\"Ce email est déja utilisé \")</script>";
}
else {
$stmt = $idcon->prepare('UPDATE formulaire SET  email= :email WHERE id = :id');
$stmt->execute(array(
	'email' => $_POST['email'],
	'id' =>$_SESSION['id'],
	
	));

 $_SESSION['email']=$_POST['email'];

}}
if ($_POST['birthday']) {

$stmt = $idcon->prepare('UPDATE formulaire SET  birthday= :birthday WHERE id = :id');
$stmt->execute(array(
	'birthday' => $_POST['birthday'],
	'id' =>$_SESSION['id'],
	
	));

 $_SESSION['birthday']=$_Post['birthday'];

}



header('location: profile.php');
	}
?>
