<?php 
function form_profile($first,$last,$ema,$bir){

Require "prof.php";
include "../head.php";

try
{
	include 'connexion.php' ;
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}


// verifier si l'utilisateur est connecté 


$image="profile/images/".$_SESSION['avatar'];
$req = $idcon->prepare("SELECT * FROM formulaire WHERE id= ? ");
$req->execute(array($_SESSION['id']));
$donnes=$req->fetch(); 
$photo ="images/".$_SESSION['avatar'];
?>

<head>
		<link rel="stylesheet" href="news.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y" crossorigin="anonymous">
</head>
<body>


<form action="prof.php" enctype="multipart/form-data" method="POST">
<title>Test</title>
</head>
<body>
<header>  
	 <h3>Weclome To LearnFast <span>.</span></h3>
	   
           <p> <a href="../index.php">Accueil</a>  </p>      
       
</header>
<div class ="container">

<div >
 <img src="<?php echo $photo ?> " alt="">
</div>
<div class="textbox">
	<h1>FirstName</h1>
	<?php if($first) { ?>
<input type="text" name="firstname" value="<?php echo $donnes['firstname'] ?>" >	
	<?php  } else { ?>
	 <p> <?php echo $donnes['firstname'] ?> <a href="firstname.php"> <i class="fas fa-edit"> </i></a> </p> 
<?php 
	}

	?>
</div>

<div class="textbox">

	<h1>Lastname</h1>
<?php if($last) { ?>
<input type="text" name="lastname" value ="<?php echo $donnes['lastname'] ?>">
<?php } else { ?>
  <p> <?php echo $donnes['lastname'] ?> <a href="lastname.php" > <i class="fas fa-edit" ></i> </a></p> 
<?php 
}
?>

</div>
<div class="textbox">
	 <h1>Email</h1>
	 <?php if ($ema)  {	 ?>
 <input type="email" name="email" value="<?php echo $donnes['email'] ?>"> 
	 <?php  } else { ?>
	 <p> <?php echo $donnes['email'] ?> <a href="email.php"><i class="fas fa-edit" ></i></a></p> 
<?php }?>



</div>
<div class="textbox">
	<h1>Birthday</h1>
	<?php if ($bir) { ?>
		<input type="date" name="birthday" value="<?php echo $donnes['birthday'] ?>">
	<?php } else { ?> 
	<p><?php echo $donnes['birthday'] ?> <a href="birthday.php"> <i class="fas fa-edit" ></i> </a></p>
<?php }
?>
</div>
<div class="sum" >	

             <input type="file" name="avatar" >


             <input type="submit" value="Enregistrer" name="save-user" >
        </div>
      </div>
</form>
</body>
<?}
 
