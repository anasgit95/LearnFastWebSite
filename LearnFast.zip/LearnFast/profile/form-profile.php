<?php 
function form_profile($first,$last,$ema,$bir){

Require "prof.php";

try
{
	include 'connexion.php' ;
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}


// verifier si l'utilisateur est connecté 


$image="profile/images/".$_SESSION['avatar'];
$req = $idcon->prepare("SELECT * FROM formulaire WHERE id= ? ");
$req->execute(array($_SESSION['id']));
$donnes=$req->fetch(); 
$photo ="images/".$_SESSION['avatar'];
?>

<!DOCTYPE html>
<html>
<html lang="en" class="no-js">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="canonical" href="https://html5-templates.com/" />
    <title>Education WebSite</title>
	<meta name="description" content="A minimalist Bootstrap theme by StartBootstrap. Contains everything you need to get started building your website. All you have to do is change the text and images.">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/modern-business.css" rel="stylesheet">
    <link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="test.css">
</head>


	<?php

Require 'head.php' ;
// verifier si l'utilisateur est connecté 
if( isset($_SESSION['id']) ) 
{
$welcome=$_SESSION['firstname'];
$deconnexion='Deconnexion';
$nothing = " " ;
$image="images/".$_SESSION['avatar'];
$type =$_SESSION['type'];
}
else 
 {
    $welcome="to learn fast " ;
    $deconnexion="login ";
    $nothing="Inscription";
    $image="no";
    $type="";
}
 
     form_head($welcome,$deconnexion,$nothing,$image,$type)
        
?>

<body>
	




<form action="prof.php" enctype="multipart/form-data" method="POST">
<title>Test</title>


<div class="All">

<div class="image" >
 <img src="<?php echo $photo ?> " alt="">
</div>
<div class="textbox">
	<h1>FirstName</h1>
	<?php if($first) { ?>
<input type="text" name="firstname" value="<?php echo $donnes['firstname'] ?>" >	
	<?php  } else { ?>
	 <p> <?php echo $donnes['firstname'] ?> <a href="firstname.php"> <i class="fas fa-edit"> </i></a> </p> 
<?php 
	}

	?>
</div>

<div class="textbox">

	<h1>Lastname</h1>
<?php if($last) { ?>
<input type="text" name="lastname" value ="<?php echo $donnes['lastname'] ?>">
<?php } else { ?>
  <p> <?php echo $donnes['lastname'] ?> <a href="lastname.php" > <i class="fas fa-edit" ></i> </a></p> 
<?php 
}
?>

</div>
<div class="textbox">
	 <h1>Email</h1>
	 <?php if ($ema)  {	 ?>
 <input type="email" name="email" value="<?php echo $donnes['email'] ?>"> 
	 <?php  } else { ?>
	 <p> <?php echo $donnes['email'] ?> <a href="email.php"><i class="fas fa-edit" ></i></a></p> 
<?php }?>



</div>
<div class="textbox">
	<h1>Birthday</h1>
	<?php if ($bir) { ?>
		<input type="date" name="birthday" value="<?php echo $donnes['birthday'] ?>">
	<?php } else { ?> 
	<p><?php echo $donnes['birthday'] ?> <a href="birthday.php"> <i class="fas fa-edit" ></i> </a></p>
<?php }
?>
</div>
<div class="sum" >	

             <input type="file" name="avatar" >


             <input type="submit" value="Enregistrer" name="save-user" >
        </div>
      </div>
</form>
</body>
<?}
 
