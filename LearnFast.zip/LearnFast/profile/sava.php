<?php
session_start();
Require  'connexion.php' ;
if (isset($_POST['save']) )
{
if (!empty($_POST['firstname'])) {	
$firstname=$_POST['firstname'];
$stmt=$idcon->prepare('UPDATE formulaire set firstname=:firstname where id=:id');
$stmt->execute(array(
	'firstname' => $firstname,
	'id' =>$_SESSION['id'],
	
	));
}

if (!empty($_POST['lastname'])) {	
$lastname=$_POST['lastname'];
$stmt=$idcon->prepare('UPDATE formulaire set lastname=:lastname where id=:id');
$stmt->execute(array(
	'lastname' => $lastname,
	'id' =>$_SESSION['id'],
	
	));
}
else 
{


}
}
header('location: profile.php');


?>