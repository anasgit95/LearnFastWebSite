
<?php
try
{
	include 'connexion.php' ;
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

if(isset($_POST['save'])) {
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email= $_POST['email'];
$password = $_POST['password'] ;
$birthday =$_POST['birthday'];
$req = $idcon->prepare('SELECT * FROM formulaire WHERE email = ?');
$req->execute(array($email));
if ($donnees=$req->fetch()){
	echo "ce email existe déja ressayer " ;
    
	header('Location:inscription.php');

}
else {
$stmt=$idcon->prepare("insert into formulaire(firstname,lastname,email,password,birthday) VALUES(?,?,?,?,?)");
$stmt->bindParam(1,$firstname);
$stmt->bindParam(2,$lastname);
$stmt->bindParam(3,$email);
$stmt->bindParam(4,$password);
$stmt->bindParam(5,$birthday);
$stmt->execute();


header('Location:../index.php');
}
}


?>