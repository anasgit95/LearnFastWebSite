<?php
try
{
	include 'connexion.php' ;
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

if(isset($_POST['login'])) {

$email= $_POST['email'];
$password = $_POST['password'] ;


$req = $idcon->prepare("SELECT * FROM formulaire WHERE email= ? AND password= ?");
$req->execute(array($email, $password));
if($donnees = $req->fetch())
{
	session_start();
	$_SESSION['id']=$donnees['id'];
	$_SESSION['firstname']=$donnees['firstname'];
	header('Location:../index.php');

}

else echo "Compte ou mot de passe incorrect";

}


?>