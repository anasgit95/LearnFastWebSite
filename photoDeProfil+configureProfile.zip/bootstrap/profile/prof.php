<?php 
session_start();


Require  'connexion.php' ;
if (isset($_POST['save-user']) )
{
$id =$_POST['id'];
if (!empty($_POST['firstname'])) {	
$firstname=$_POST['firstname'];
}
else $firstname=$_SESSION['firstname'] ;
$lastname=$_POST['lastname'];
$email= $_POST['email'];
$password = $_POST['password'] ;
$birthday =$_POST['birthday'];


$stmt=$idcon->prepare('UPDATE formulaire set firstname=:firstname,lastname=:lastname,email=:email,password=:password,birthday=:birthday where id=:id');
$stmt->execute(array(
	'firstname' => $firstname,
	'lastname' =>$lastname,
	'email' => $email,
	 'password'=>$password,
	'birthday' =>$birthday,
	'id' =>$_SESSION['id'],
	
	));

$stmt->execute();

    $profileImageName=time().'_'.$_FILES['avatar']['name'];
    $target='images/'.$profileImageName ;
   

   if ( move_uploaded_file($_FILES['avatar']['tmp_name'],$target)) {

$stmt = $idcon->prepare('UPDATE formulaire SET  avatar = :avatar WHERE id = :id');
$stmt->execute(array(
	'avatar' => $profileImageName,
	'id' =>$_SESSION['id'],
	
	));

 $_SESSION['avatar']=$profileImageName;
}

header('location: profile.php');
}
?>
